package meryem.emsi.clientjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientJavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
