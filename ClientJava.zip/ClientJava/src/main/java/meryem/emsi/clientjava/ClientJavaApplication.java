package meryem.emsi.clientjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClientJavaApplication.class, args);
    }

}
