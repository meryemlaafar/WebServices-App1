@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://WS/")
package proxy;
