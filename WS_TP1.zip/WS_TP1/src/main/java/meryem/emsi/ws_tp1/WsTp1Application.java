package meryem.emsi.ws_tp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsTp1Application {

    public static void main(String[] args) {
        SpringApplication.run(WsTp1Application.class, args);

    }

}
